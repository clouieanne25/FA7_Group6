# Part 2 - Normal Distribution
# Topic: Weight of students' backpacks

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv("data.csv")
x = df["backpack_weight_kg"]

mu = x.mean()
sigma = x.std(ddof=1)

print("n =", len(x))
print("Mean =", mu)
print("Sample standard deviation =", sigma)

for k in [1,2,3]:
    pct = ((x >= mu-k*sigma) & (x <= mu+k*sigma)).mean()*100
    print(f"Within {k} sigma: {pct:.2f}%")

plt.hist(x, bins=10, density=True, alpha=0.55, edgecolor="black")
xx = np.linspace(x.min()-0.2, x.max()+0.2, 300)
pdf = 1/(sigma*np.sqrt(2*np.pi))*np.exp(-0.5*((xx-mu)/sigma)**2)
plt.plot(xx,pdf,linewidth=2)
plt.xlabel("Backpack weight (kg)")
plt.ylabel("Density")
plt.title("Backpack Weights and Normal Curve")
plt.show()
