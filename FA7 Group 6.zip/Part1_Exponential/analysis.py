# Part 1 - Exponential Distribution
# Topic: Time intervals between students entering a campus restroom

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv("data.csv")
x = df["interval_minutes"].dropna()

mean_interval = x.mean()
lam = 1 / mean_interval

print("n =", len(x))
print("Mean interval (minutes) =", mean_interval)
print("Lambda (per minute) =", lam)
print("P(X <= 1) =", 1-np.exp(-lam*1))
print("P(X <= 2) =", 1-np.exp(-lam*2))
print("P(X <= 3) =", 1-np.exp(-lam*3))
print("P(X > 5) =", np.exp(-lam*5))

plt.hist(x, bins=8, density=True, alpha=0.65, edgecolor="black")
xx = np.linspace(0, x.max()*1.05, 300)
plt.plot(xx, lam*np.exp(-lam*xx), linewidth=2)
plt.xlabel("Time interval (minutes)")
plt.ylabel("Density")
plt.title("Observed Intervals and Exponential PDF")
plt.show()
